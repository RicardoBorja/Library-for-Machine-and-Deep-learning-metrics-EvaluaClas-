
#' Base de datos
#'
#' Funcin para cambiar la base de datos a numericas
#' @param data.frame.1M data-set matrix with data containing the metagenomic frequencies (rows: OTUs, columns: samples)
#' @param saturation if TRUE the matrix is ordered
#' @param method additive regression or xgboost
#' @export


##################################################################################
# PREPARACION DE DATOS - SI SE TIENE UNA BASE DE DATOS 
##################################################################################

#---------------------------------------------------------------------
#Cambio a categorias numericas 

base_datos <- function(r2=r2){

  r2 <- Fun_cam_cate(r2=r2)

  le <- levels(r2[,1])
  NC <- as.numeric(length(le)) # Numero  de categorias
  tamano.muestral <- as.numeric(nrow(r2))
  n1 <- as.numeric(ncol(r2)) # numero de observadores
  num_obs <- ncol(r2) # Numero de observadores 

  return(list(
    NC <- NC,
    tamano.muestral <- tamano.muestral,
    r2 <- r2,
    n1 <- n1,
    num_obs <- num_obs
  ))

}
