
# An?lisis  de accuracy, kappa y f1 score segun el tama?o muestral


red_graf <- function(r2=r2,n1=n1, NC=NC){

# Reduccion de datos a 4 niveles 10, 25, 50, 75 y 100% del general--
  dat <- r2
  red <- c(10,25,50,75,100)
  d <- NULL
  t <- " "
  matrix1 <- matrix()
  matrixx1 <- matrix()
  name <- character()

  for (k in 1:5) {

  c = c(NULL,NULL, NULL)

  if (k==5) {dat_red <- r2}  #Para sacar el 100% de datos

  if (k!=5) {
    NumDatos <- as.numeric(length(dat[,1]))
    Numcol <- as.numeric(ncol(dat))
    indices <- sample(1:NumDatos)
    dat_red <- dat[indices,]

    Reduccion <- round(NumDatos*(red[k]/100))
    dat_red <- as.matrix(dat_red[(1:Reduccion),])
  }
#-----------------------------------------------------------------
#calulo de accuracy, kappa y f1 todas las posibilidades para una sola base reducida
  for (j in 1:(n1-1)) {
    for (i in j:(n1-1)) {

      data <- as.factor(dat_red[,j])
      data2 <- as.factor(dat_red[,(i+1)])

      tab1 <- table(data2, data) # Para constatar que no exista categorias faltantes y en caso trabajar con el if
      if(nrow(tab1)!=ncol(tab1)){
        conf.table <- mis_Conf_Mat(real=data,pred=data2)} #MAtriz de confusion con missing

      if(nrow(tab1)==ncol(tab1)){
        conf.table<- (confusionMatrix(as.factor(data2), as.factor(data)))} # Para el caso que las categorias sean iguales en los dos datos

  # Valores de Accuracy----------------------------------
      r <- round(as.matrix(conf.table[[3]][1]),5)

  # Valores de kappa------------------------------------

      g <- round((as.matrix(cohen.kappa(cbind(data, data2), alpha=0.05,levels=NULL)$confid)[1,]),5)[2]
      g <- t(t(g))

  # Para guardar F1 score ------------------------------
      f1 <- round(as.matrix(F1_Score(data,data2)),5)

  # Para guardar matriz general-------------------------
      w <- rbind(r,g,f1)
      matrix1 <- cbind(c,w)
      c <- matrix1

      row.names(matrix1)[1] <- paste("Accuracy_",red[k])
      row.names(matrix1)[2] <- paste("Kappa_",red[k])
      row.names(matrix1)[3] <- paste("F1_",red[k])

    }
  }
# ----------------------------------------------------------------
  matrixx1 <- rbind(t,matrix1,d)
  d <- matrixx1
  }
# Nombres del tama?o muestral y nombres de columnas---------------
  row.names(matrixx1)[1] <- paste("sample_size:100%")
  row.names(matrixx1)[5] <- paste("sample_size:75%")
  row.names(matrixx1)[9] <- paste("sample_size:50%")
  row.names(matrixx1)[13] <- paste("sample_size:25%")
  row.names(matrixx1)[17] <- paste("sample_size:10%")

  t <- 0
  for (j in 1:(n1-1)) {
    for (i in j:(n1-1)) {
      name[i+t] <- paste(as.character(j),"-",as.character(i+1))
      te <- (i+t)
    }
    t <- (te-j)
  }
  colnames(matrixx1) <- name
# ----------------------------------------------------------------
# Extraer valores
  if (NC==2){
    accura <- as.numeric(matrixx1[c(18,14,10,6,2),])
    kap <- as.numeric(matrixx1[c(19,15,11,7,3),])
    F1_ <- as.numeric(matrixx1[c(20,16,12,8,4),])
  }

  if (NC!=2){
    accura <- matrixx1[c(18,14,10,6,2),]
    kap <- matrixx1[c(19,15,11,7,3),]
    F1_ <- matrixx1[c(20,16,12,8,4),]
  }


# Generar graficas--------------------------------------
  if (NC==2){
    for (i in 1:(as.numeric(NC-1))) {

      pdf(paste("Comparison_",name,".pdf"))
      plot(accura, lty=1,type = "l", col="magenta", main=paste("Comparison kappa versus F1 versus accuracy-par:",name[i]),xlab=paste("Sample size: 10%, 25%, 50%, 75%, 100%"),ylab = "", lwd=1.5 ,ylim=c(min(as.numeric(accura),as.numeric(kap),as.numeric(F1_)-0.30),(max(as.numeric(accura),as.numeric(kap),as.numeric(F1_)))+0.10),cex.main=1)
      lines(kap, col="red",lwd=1)
      lines(F1_, col="blue",lwd=1.5)

      legend("topright", c("Accuracy", "kappa index","F1"),lty = 1,col = c("magenta","red", "blue"), cex= 1)
      dev.off()
    }
  }

  if (NC!=2){
    for (i in 1:(as.numeric(ncol(accura)))) {

      pdf(paste("Comparison_",name[i],".pdf"))
      plot(accura[,i], lty=1,type = "l", col="magenta", main=paste("Comparison kappa versus F1 versus accuracy-par:",name[i]),xlab=paste("Sample size: 10%, 25%, 50%, 75%, 100%"),ylab = "", lwd=1.5 ,ylim=c(min(as.numeric(accura[,i]),as.numeric(kap[,i]),as.numeric(F1_[,i])-0.30),(max(as.numeric(accura[,1]),as.numeric(kap[,i]),as.numeric(F1_[,i])))+0.10),cex.main=1)
      lines(kap[,i], col="red",lwd=1)
      lines(F1_[,i], col="blue",lwd=1.5)

      legend("topright", c("Accuracy", "kappa index","F1"),lty = 1,col = c("magenta","red", "blue"), cex= 1)
      dev.off()
    }
  }


# -----------------------------------------------------

  mat <- as.data.frame(matrixx1)

  wide_win <- as.numeric((ncol(r2)*3)+1)
  ven_wid <- wide_win # Tamano de la ventana de salida pdf del reporte

  pdf(paste("Metrics_sample_sizes.pdf"), height=11, width=ven_wid)
  grid.table(mat)
  dev.off()

  return(mat)
}
