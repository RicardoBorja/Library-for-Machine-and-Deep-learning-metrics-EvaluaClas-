

Paq_nec <- function(){

  if(!require("psych")) install.packages("psych")# necesario para fun cohen.kappa
  if(!require("caret")) install.packages ( "caret" ) #necesario matriz de confusion
  if(!require("pROC")) install.packages ( "pROC" ) # necesario para ROC
  if(!require("ROCR")) install.packages ( "ROCR" ) # necesario para ROC
  if(!require("DMwR")) install.packages ( "DMwR" ) # necesario para imputacion knn
  if(!require("REdaS")) install.packages ( "REdaS" ) # para MLmetric
  if(!require("MLmetrics")) install.packages("MLmetrics") # es necesario para f1 score
  if(!require("gridExtra")) install.packages ( "gridExtra" ) ## para MLmetric
  
 
  require("psych")
  require ("caret")
  require("pROC")
  require("ROCR")
  require("DMwR")
  require("gridExtra")
  require ("MLmetrics")
  require("REdaS")
  graphics.off()
}

