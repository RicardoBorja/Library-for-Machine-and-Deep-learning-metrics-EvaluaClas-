

Cur_ROC <- function(r2=r2,NC=NC){

  #NC1 <- as.numeric(length(levels(r2[,1]))) # Numero  de categorias
  NC1 <- NC
  r3 <- r2
  b <-NULL
  c <- NULL
  auc_d <- matrix()
  auc_t <-  matrix()

#----------------------------------------------------------
# Para cambiar el nivel
  for (m in 1:NC1) {

    b <-NULL
    r3 <- r2
# Para hacer dicotomico cada columna de la base de datos
    for (l in 1:as.numeric(ncol(r3))) {
      for (k in 1:as.numeric(nrow(r3))) {
        if (as.numeric(r3[k,l])== m){r3[k,l]<- 1}
        else {r3[k,l]<- 2}
      }}
# Para cambiar los datos de 4 niveles unicamente a 2
    for (t in 1:as.numeric(ncol(r3))) {r3[,t] <- factor( r3[,t],c(1,2))}
#----------------------------------------------------------
#---------------------------------------------------------------------------
  # Para tomar todas las parejas pposibles
    for (j in 1:(NC1-1)) {
      for (i in j:(NC1-1)) {

# Grafica de curva ROC
      pred <- prediction( as.numeric(r3[,as.numeric(j)]),as.numeric(r3[,as.numeric(i+1)]) )
      perf <- performance(pred, measure = "sens", x.measure = "fpr" )

# AUC
      auc_d <- ((roc(as.numeric(r3[,j]),as.numeric(r3[,(i+1)]),auc = TRUE))$auc)[1]
      ac <- round(auc_d,3)
      auc_d <- cbind(b, auc_d)
      b <-auc_d


# Impresion pdf de graficas

#--------------------------------------------------------------



      # Para hacer el pdf
      pdf(paste("ROC_curve_class",m,"_",j,(i+1),".pdf"))
      plot(perf, colorize = TRUE, type = "l", main= paste("ROC CURVE - CLASS",m,"_",j,(i+1),"(AUC=",ac,")")) #out
      abline(a = 0, b = 1 )
      dev.off()
      }
    }
#---------------------------------------------------------------------------
    auc_t <- (rbind(c, auc_d))
    c <- auc_t
  }


return(auc_t)
}






