#' Fun cambio a categorias
#'
#' Funcin para cambiar a actegorias
#' @param data.frame.1M data-set matrix with data containing the metagenomic frequencies (rows: OTUs, columns: samples)
#' @param saturation if TRUE the matrix is ordered
#' @param method additive regression or xgboost
#' @export

# Cambio a categorias numericas 

Fun_cam_cate <- function(r2=r2){
  # Caracteristicas
  le <- levels(r2[,1])
  num_le <- length(le)
  cam <- as.character(1:num_le)
  num_col <- as.numeric(ncol(r2))
  # Cambio a categorias numericas 
  for (i in 1:num_col) {
    levels(r2[,i]) <- cam
  }
  return(r2)
}




