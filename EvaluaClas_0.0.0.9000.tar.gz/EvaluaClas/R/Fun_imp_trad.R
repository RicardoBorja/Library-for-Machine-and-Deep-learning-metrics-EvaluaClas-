

# Funcion para consultar que imprimir

Fun_imp_trad <- function(r2=r2, lista3=list_final, n1=n1,auc_d=auc_d,NC=NC){
  d1 <- " "
  sta_over <- lista3
  nam <- as.numeric(nrow(sta_over)) # Para nombre de auc
  auc_d <- as.matrix(auc_d)

  sta_over <- rbind(sta_over,d1,round(auc_d,5))
  row.names(sta_over)[nam+1] <- "AUC"
  row.names(sta_over)[(nam+2):(nam+1+NC)] <- paste("Class",1:NC)

  li_final <- as.data.frame(sta_over) # escoje las columnas para formar los pares solucion
  li_final <- as.data.frame(li_final)
  name <- character()

  t <- 0
  for (j in 1:(n1-1)) {
    for (i in j:(n1-1)) {
      name[i+t] <- paste(as.character(j),"-",as.character(i+1))
      te <- (i+t)
    }
      t <- (te-j)
  }
  names(li_final) <- name

  return(li_final)
}



