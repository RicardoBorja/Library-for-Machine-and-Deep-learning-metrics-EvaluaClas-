#' Comparator evaluator of machine learning and deep learning classifiers.
#' @description It allows to obtain the values of Precision, Recall, F1 score, ROC curve and confusion matrix that allow to make a decision of the quality of a classifier and its comparison with other classifiers, product of the application of machine learning and deep learning techniques.
#'
#' The function programmed for this package is Eval_clas () and has the following default values:
#'
#' EvaluaClas <- function(data=FALSE)
#'
#' @param data Specify the name of the database file of type "dataframe" to be analyzed previously loaded in R, with the standard Gold located in the first column.
#' @return Precision, Recall, F1 score, ROC curve and confusion matrix.
#'
#' @examples
#'
#'
#' Autor: Ricardo Stalin Borja Robalino
#' @export


##################################################################################
#                            PROGRAMA BASE
##################################################################################

EvaluaClas <- function(data=FALSE){


#-------------------------------------------------------------
# INSTALACION DE PAQUETES NECESARIOS
  Paq_nec()

  print(Fun_men1(), quote=FALSE)

#-------------------------------------------------------------
# PREPARACION DE DATOS - CAMBIO A CATEGORIAS NUMERICAS

  r2 <- data
  L <- as.numeric(length(r2))

  if (L!=1 ){
    list_one <- base_datos(r2=r2)
    NC <- list_one[[1]]
    tamano.muestral <- list_one[[2]]
    r2 <- list_one[[3]]
    n1 <- list_one[[4]]
    num_obs <- list_one[[5]]

  }

#-------------------------------------------------------------
# TRATAMIENTO DE MISSING

  r2 <- knnImputation(r2,k=5)

#-------------------------------------------------------------
# ANALISIS FRECUENTISTA kappa, accuracy, f1 score, recall

  lis_final <- Fun_ana_disc(r2=r2, n1=n1,NC=NC)
  list_final <- lis_final[[1]]
  matrconf <- lis_final[[2]]

#-------------------------------------------------------------
# Graficas pdf de Curva ROC y AUC

  auc_d <- Cur_ROC(r2=r2,NC=NC)

#--------------------------------------------------------------
# Reporte final generado

  Repo_final <- Fun_imp_trad(r2=r2, lista3=list_final, n1=n1,auc_d=auc_d,NC=NC )

#--------------------------------------------------------------
# Reduccion en el tamano muestral, determina accuracy, kappa y f1. Finalmente realiza una grafica general

  metr_mues <- red_graf(r2=r2,n1=n1, NC=NC)


#--------------------------------------------------------------
# REPORTES FINALES EN PDF

  wide_win <- as.numeric((ncol(r2)*3)+1)
  ven_wid <- wide_win # Tamano de la ventana de salida pdf del reporte

  TM <- nrow(r2)
  pdf(paste("Evaluation_metrics",TM,".pdf"), height=11, width=ven_wid)
  grid.table(Repo_final)
  dev.off()

#-------------------------------------------------------------
# IMPRESION DE RESULTADOS EN LA CONSOLA
  mensaje <- Fun_men3()
  print(mensaje, quote=FALSE)
  print(" ", quote=FALSE)
  print(" ", quote=FALSE)
  print(" ", quote=FALSE)
  print("Final report of all the metrics of evaluation of classifiers", quote=FALSE)
  print(" ", quote=FALSE)
  print(Repo_final, quote=FALSE)
  print(" ", quote=FALSE)
  print(" ", quote=FALSE)
  print("Final report of the metrics accuracy, kappa index and F1 score for sample sizes of 10%, 25%, 50% and 100% of the data.", quote=FALSE)
  print(" ", quote=FALSE)
  print(metr_mues, quote=FALSE)


#------------------------------------------------------------
# DATOS DEVUELTOS
  return(list(
    Report_final <- Repo_final,
    metr_muest <- metr_mues,
    matrconfu <- matrconf
    ))

}



