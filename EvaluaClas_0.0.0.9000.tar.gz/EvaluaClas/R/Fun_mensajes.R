

Fun_men1 <- function(){
  mensaje0 <- "You must load the database to R locating the gold"
  mensaje00 <-"standard in the first column, the file should be"
  mensaje1 <- "data frame. "
  mensajet1 <- rbind(mensaje0,mensaje00,mensaje1)
  rownames(mensajet1) <- c("","","")
  colnames(mensajet1) <- ""
  return(mensajet1)
}


Fun_men3 <- function(){
  mensaje0 <- "As an output you have a list in R of the final"
  mensaje1 <- "report with all the metrics and the accuracy"
  mensaje2 <- "report, indce kappa and F1 analyzed on the basis"
  mensaje3 <- "of 10%, 25%, 50% and 100% data that will allow"
  mensaje4 <- "you to observe its sensitivity."
  mensaje5 <- "The corresponding graphs and final reports are"
  mensaje6 <- "available in pdf format at the work address of R"
  mensajet1 <- rbind(mensaje0,mensaje1,mensaje2,mensaje3,mensaje4,mensaje5,mensaje6)
  rownames(mensajet1) <- c("","","","","","","")
  colnames(mensajet1) <- ""
  return(mensajet1)
}
