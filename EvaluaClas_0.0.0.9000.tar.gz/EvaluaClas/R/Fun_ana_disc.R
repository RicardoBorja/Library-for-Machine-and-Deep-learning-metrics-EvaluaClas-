#' Funcion de analisis discriminante
#'
#' Funcin para calcular el analisis discriminante
#' @param data.frame.1M data-set matrix with data containing the metagenomic frequencies (rows: OTUs, columns: samples)
#' @param saturation if TRUE the matrix is ordered
#' @param method additive regression or xgboost
#' @export

# Funcion para el analisis discriminante

Fun_ana_disc <- function(r2=r2, n1=n1, NC=NC){
  matrix2 <- matrix() # guarda datos de Overall Statistics y statistics by class
  matrix3 <- matrix()
  matrix4 <- matrix()
  Pe <- matrix()
  conf <- list()
  kap <- c("unweighted KappaLower", "Kappa" ,"unweighted KappaUpper")
  c =NULL
  e =NULL
  f= NULL
  b= NULL
  d1= ""

    for (j in 1:(n1-1)) {
    for (i in j:(n1-1)) {

      data <- r2[,j]
      data2 <- r2[,(i+1)]

      tab1 <- table(data2, data) # Para constatar que no exista categorias faltantes y en caso trabajar con el if
      if(nrow(tab1)!=ncol(tab1)){
        conf.table <- mis_Conf_Mat(real=data,pred=data2)} #MAtriz de confusion con missing

      if(nrow(tab1)==ncol(tab1)){
        conf.table<- (confusionMatrix(as.factor(data2), as.factor(data)))} # Para el caso que las categorias sean iguales en los dos datos

         # Valores de Accuracy----------------------------------
         d <-  round(as.matrix(conf.table[[3]][c(3,1,4)]),5)
         d <- rbind(d,d1)
         d <- as.matrix(d)

         # Valores de kappa----------------------------------

         g <- round((as.matrix(cohen.kappa(cbind(data, data2), alpha=0.05)$confid)[1,]),5)
         names(g) <- kap
         g <- t(t(g))
         d <- rbind(d,g)
         matrix2 <- cbind(c,d)
         c=matrix2
         #-------------------------------------------------------

         # Para determinar Pe mediante kappa-------------------
         ka <- as.numeric((cohen.kappa(cbind(data, data2), alpha=0.05))[[1]])
         ac <- as.numeric(d[2])
         Pe <- round((ac-ka)/(1-ka),5) # Precision esperada unicamente por azar
         Pe <- cbind(b,Pe)
         b=Pe
         #--------------------------------------------------------------

         if (NC==2){Sen <- as.matrix(round((conf.table$byClass[1:4]),5))}
         else {Sen <- as.matrix(round((conf.table$byClass[,1]),5))}

         matrix3 <- cbind(e,Sen)
         e=matrix3

         # Para guardar la lista de la matriz de confianza
         if (j==1){conf[[i]] <- list(conf.table[[2]])}
         else {conf[[(i+(n1-1)+(j-2))]] <- list(conf.table[[2]])}

         # Para guardar F1 score
         matrix4 <- round(as.matrix(F1_Score(data,data2)),5)
         matrix4 <- cbind(f,matrix4)
         f=matrix4
    }

  }



  if (NC!=2){
    matrix2 <- rbind(d1,matrix2,Pe,d1,matrix3,d1,matrix4)
    row.names(matrix2)[1] <- "Accuracy"
    row.names(matrix2)[5] <- "Kappa_index"
    row.names(matrix2)[9] <- "Expected_accuracy"
    row.names(matrix2)[10] <- "Sensitivity_Recall"
    row.names(matrix2)[11+as.numeric(NC)] <- "F1_Score"
    row.names(matrix2)[11+as.numeric(NC)+1] <- "F1"
  }

  if (NC==2){
    matrix2 <- rbind(d1,matrix2,Pe,d1,matrix3,d1,matrix4)
    row.names(matrix2)[1] <- "Accuracy"
    row.names(matrix2)[5] <- "Kappa_index"
    row.names(matrix2)[9] <- "Expected_accuracy"
    row.names(matrix2)[10] <- "Additional metrics"
    row.names(matrix2)[11] <- "Sensitivity"
    row.names(matrix2)[12] <- "Specificity"
    row.names(matrix2)[13] <- "Pos Pred Value"
    row.names(matrix2)[14] <- "Neg Pred Value"
    row.names(matrix2)[15] <- "F1_Score"
    row.names(matrix2)[16] <- "F1"
  }


return(list(
  matrix2 <- matrix2,
  mat_conf <- conf))
}

