
#' Matriz de confusion para el caso de clases faltantes
#'
#' Funcin para calcular el analisis bayesiano
#' @param data.frame.1M data-set matrix with data containing the metagenomic frequencies (rows: OTUs, columns: samples)
#' @param saturation if TRUE the matrix is ordered
#' @param method additive regression or xgboost
#' @export

# Funcion de matriz de confusion en el caso de tener categorias faltantes (missing)

mis_Conf_Mat <- function(real=data,pred=data2) {
  act <- as.integer(real)
  pred <- as.integer(pred)
  u <- union(pred, act) # realizo la union para obtener  todas las clases 
  u <- u[order(u)] # ordeno 
  t <- table(factor(pred, u), factor(act, u)) # hago la tabla, el factor completa los ceros
  conf.table <- confusionMatrix(t) 
  return(conf.table)
}
